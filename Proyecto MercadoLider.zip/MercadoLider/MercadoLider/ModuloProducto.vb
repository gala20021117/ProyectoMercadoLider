﻿Imports MySql.Data.MySqlClient
Imports System.IO

Module ModuloProducto
    Dim conexion As MySqlConnection
    Dim cmd As New MySqlCommand
    Dim Sql As String
    Public Function buscador(ByVal descripcionbuscar As String, ByVal categoria As String, ByVal bnAtras As Integer, ByVal restar As Boolean, ByVal categoriaParamMenu As String, ByVal BuscarPorCategoria As String) As Boolean

        Dim a As Boolean
        Dim DataAdapter As MySqlDataAdapter
        Dim oDataSet As New DataSet
        Dim nombre1, nombre2, nombre3, nombre4, nombre5, nombre6, nombre7, nombre8 As String
        Dim precio1, precio2, precio3, precio4, precio5, precio6, precio7, precio8 As Integer
        Dim codigo1, codigo2, codigo3, codigo4, codigo5, codigo6, codigo7, codigo8 As Integer
        Dim fotoPort1, fotoPort2, fotoPort3, fotoPort4, fotoPort5, fotoPort6, fotoPort7, fotoPort8 As Byte()
        Dim fotoPort11, fotoPort22, fotoPort33, fotoPort44, fotoPort55, fotoPort66, fotoPort77, fotoPort88 As Image

        Dim cantidad As Integer = 0
        Dim uno As Integer = 1
        Dim dos As Integer = 2
        Dim tres As Integer = 3
        Dim cuatro As Integer = 4
        Dim cinco As Integer = 5
        Dim seis As Integer = 6
        Dim siete As Integer = 7
        Dim ocho As Integer = 8

        If restar = False Then

            uno = bnAtras + uno
            dos = bnAtras + dos
            tres = bnAtras + tres
            cuatro = bnAtras + cuatro
            cinco = bnAtras + cinco
            seis = bnAtras + seis
            siete = bnAtras + siete
            ocho = bnAtras + ocho
        Else
            uno = bnAtras - uno
            dos = bnAtras - dos
            tres = bnAtras - tres
            cuatro = bnAtras - cuatro
            cinco = bnAtras - cinco
            seis = bnAtras - seis
            siete = bnAtras - siete
            ocho = bnAtras - ocho
        End If
        conexion = New MySqlConnection

        Try
            Dim server As String = "server=localhost; database=mercado_lider; Uid=user555; Pwd=140403,Softec;"
            Dim conexion As New MySqlConnection(server)
            Dim cmd As New MySqlCommand
            conexion.Open()

            Sql = "SELECT Codigo, Nombre, Precio, FotoPortada FROM `articulos` WHERE `descripcion` LIKE '%" & descripcionbuscar & "%'"



            DataAdapter = New MySqlDataAdapter(Sql, conexion)
            oDataSet.Clear()
            DataAdapter.Fill(oDataSet, "listarProductos")


            cantidad = oDataSet.Tables("listarProductos").Rows.Count()

            If cantidad >= uno Then
                nombre1 = oDataSet.Tables("listarProductos").Rows(bnAtras + 0).Item("Nombre")
                precio1 = oDataSet.Tables("listarProductos").Rows(bnAtras + 0).Item("Precio")
                fotoPort1 = oDataSet.Tables("listarProductos").Rows(bnAtras + 0).Item("FotoPortada")
                codigo1 = oDataSet.Tables("listarProductos").Rows(bnAtras + 0).Item("Codigo")
                fotoPort11 = Bytes_Imagen(fotoPort1)

                frmBuscador.GroupBox1.Visible = True

                frmBuscador.producto1.Text = nombre1
                frmBuscador.precio1.Text = precio1
                frmBuscador.pct1.Image = fotoPort11
                frmBuscador.cod1.Text = codigo1
                frmBuscador.btnSiguiente.Enabled = True

            Else
                frmBuscador.GroupBox1.Visible = False
                frmBuscador.btnSiguiente.Enabled = False
                frmBuscador.txtBuscador.Clear()
            End If

            If cantidad >= dos Then

                nombre2 = oDataSet.Tables("listarProductos").Rows(bnAtras + 1).Item("Nombre")
                precio2 = oDataSet.Tables("listarProductos").Rows(bnAtras + 1).Item("Precio")
                fotoPort2 = oDataSet.Tables("listarProductos").Rows(bnAtras + 1).Item("FotoPortada")
                codigo2 = oDataSet.Tables("listarProductos").Rows(bnAtras + 1).Item("Codigo")
                fotoPort22 = Bytes_Imagen(fotoPort2)
                frmBuscador.GroupBox2.Visible = True

                frmBuscador.producto2.Text = nombre2
                frmBuscador.precio2.Text = precio2
                frmBuscador.pct2.Image = fotoPort22
                frmBuscador.cod2.Text = codigo2
            Else
                frmBuscador.GroupBox2.Visible = False
                frmBuscador.btnSiguiente.Enabled = False
                frmBuscador.txtBuscador.Clear()
            End If

            If cantidad >= tres Then
                nombre3 = oDataSet.Tables("listarProductos").Rows(bnAtras + 2).Item("Nombre")
                precio3 = oDataSet.Tables("listarProductos").Rows(bnAtras + 2).Item("Precio")
                fotoPort3 = oDataSet.Tables("listarProductos").Rows(bnAtras + 2).Item("FotoPortada")
                codigo3 = oDataSet.Tables("listarProductos").Rows(bnAtras + 2).Item("Codigo")
                fotoPort33 = Bytes_Imagen(fotoPort3)
                frmBuscador.GroupBox3.Visible = True

                frmBuscador.producto3.Text = nombre3
                frmBuscador.precio3.Text = precio3
                frmBuscador.pct3.Image = fotoPort33
                frmBuscador.cod3.Text = codigo3
            Else
                frmBuscador.GroupBox3.Visible = False
                frmBuscador.btnSiguiente.Enabled = False
                frmBuscador.txtBuscador.Clear()
            End If

            If cantidad >= cuatro Then

                nombre4 = oDataSet.Tables("listarProductos").Rows(bnAtras + 3).Item("Nombre")
                precio4 = oDataSet.Tables("listarProductos").Rows(bnAtras + 3).Item("Precio")
                fotoPort4 = oDataSet.Tables("listarProductos").Rows(bnAtras + 3).Item("FotoPortada")
                codigo4 = oDataSet.Tables("listarProductos").Rows(bnAtras + 3).Item("Codigo")
                fotoPort44 = Bytes_Imagen(fotoPort4)
                frmBuscador.GroupBox4.Visible = True

                frmBuscador.producto4.Text = nombre4
                frmBuscador.precio4.Text = precio4
                frmBuscador.pct4.Image = fotoPort44
                frmBuscador.cod4.Text = codigo4
            Else
                frmBuscador.GroupBox4.Visible = False
                frmBuscador.btnSiguiente.Enabled = False
                frmBuscador.txtBuscador.Clear()
            End If

            If cantidad >= cinco Then

                nombre5 = oDataSet.Tables("listarProductos").Rows(bnAtras + 4).Item("Nombre")
                precio5 = oDataSet.Tables("listarProductos").Rows(bnAtras + 4).Item("Precio")
                fotoPort5 = oDataSet.Tables("listarProductos").Rows(bnAtras + 4).Item("FotoPortada")
                codigo5 = oDataSet.Tables("listarProductos").Rows(bnAtras + 4).Item("Codigo")
                fotoPort55 = Bytes_Imagen(fotoPort5)
                frmBuscador.GroupBox5.Visible = True

                frmBuscador.producto5.Text = nombre5
                frmBuscador.precio5.Text = precio5
                frmBuscador.pct5.Image = fotoPort55
                frmBuscador.cod5.Text = codigo5
            Else
                frmBuscador.GroupBox5.Visible = False
                frmBuscador.btnSiguiente.Enabled = False
                frmBuscador.txtBuscador.Clear()

            End If


            If cantidad >= seis Then

                nombre6 = oDataSet.Tables("listarProductos").Rows(bnAtras + 5).Item("Nombre")
                precio6 = oDataSet.Tables("listarProductos").Rows(bnAtras + 5).Item("Precio")
                fotoPort6 = oDataSet.Tables("listarProductos").Rows(bnAtras + 5).Item("FotoPortada")
                codigo6 = oDataSet.Tables("listarProductos").Rows(bnAtras + 5).Item("Codigo")
                fotoPort66 = Bytes_Imagen(fotoPort6)
                frmBuscador.GroupBox6.Visible = True

                frmBuscador.producto6.Text = nombre6
                frmBuscador.precio6.Text = precio6
                frmBuscador.pct6.Image = fotoPort66
                frmBuscador.cod6.Text = codigo6
            Else
                frmBuscador.GroupBox6.Visible = False
                frmBuscador.btnSiguiente.Enabled = False
                frmBuscador.txtBuscador.Clear()
            End If

            If cantidad >= siete Then

                nombre7 = oDataSet.Tables("listarProductos").Rows(bnAtras + 6).Item("Nombre")
                precio7 = oDataSet.Tables("listarProductos").Rows(bnAtras + 6).Item("Precio")
                fotoPort7 = oDataSet.Tables("listarProductos").Rows(bnAtras + 6).Item("FotoPortada")
                codigo7 = oDataSet.Tables("listarProductos").Rows(bnAtras + 6).Item("Codigo")
                fotoPort77 = Bytes_Imagen(fotoPort7)
                frmBuscador.GroupBox7.Visible = True

                frmBuscador.producto7.Text = nombre7
                frmBuscador.precio7.Text = precio7
                frmBuscador.pct7.Image = fotoPort77
                frmBuscador.cod7.Text = codigo7
            Else
                frmBuscador.GroupBox7.Visible = False
                frmBuscador.btnSiguiente.Enabled = False
                frmBuscador.txtBuscador.Clear()
            End If

            If cantidad >= ocho Then

                nombre8 = oDataSet.Tables("listarProductos").Rows(bnAtras + 7).Item("Nombre")
                precio8 = oDataSet.Tables("listarProductos").Rows(bnAtras + 7).Item("Precio")
                fotoPort8 = oDataSet.Tables("listarProductos").Rows(bnAtras + 7).Item("FotoPortada")
                codigo8 = oDataSet.Tables("listarProductos").Rows(bnAtras + 7).Item("Codigo")
                fotoPort88 = Bytes_Imagen(fotoPort8)
                frmBuscador.GroupBox8.Visible = True

                frmBuscador.producto8.Text = nombre8
                frmBuscador.precio8.Text = precio8
                frmBuscador.pct8.Image = fotoPort88
                frmBuscador.cod8.Text = codigo8
            Else
                frmBuscador.GroupBox8.Visible = False
                frmBuscador.btnSiguiente.Enabled = False
                frmBuscador.txtBuscador.Clear()
            End If



            conexion.Close()
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
        Return a
    End Function

    ' CONVERTIR IMAGEN A BINARIO
    Public Function Imagen_Bytes(ByVal Foto As Image) As Byte()
        If Not Foto Is Nothing Then
            Dim Codi As New IO.MemoryStream
            Foto.Save(Codi, Imaging.ImageFormat.Jpeg)

            Return Codi.GetBuffer
        Else
            Return Nothing
        End If
    End Function

    ' CONVERTIR BINARIO A IMAGEN
    Function Bytes_Imagen(ByVal Imagen As Byte()) As Image
        Try
            'si hay imagen
            If Not Imagen Is Nothing Then
                'caturar array con memorystream hacia Bin
                Dim Bin As New MemoryStream(Imagen)
                'con el método FroStream de Image obtenemos imagen
                Dim Resultado As Image = Image.FromStream(Bin)
                'y la retornamos
                Return Resultado
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

End Module
