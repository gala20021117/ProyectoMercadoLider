﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBuscador
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBuscador))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cod1 = New System.Windows.Forms.Label()
        Me.Link1 = New System.Windows.Forms.LinkLabel()
        Me.precio1 = New System.Windows.Forms.Label()
        Me.producto1 = New System.Windows.Forms.Label()
        Me.pct1 = New System.Windows.Forms.PictureBox()
        Me.cod8 = New System.Windows.Forms.Label()
        Me.cod7 = New System.Windows.Forms.Label()
        Me.cod6 = New System.Windows.Forms.Label()
        Me.cod5 = New System.Windows.Forms.Label()
        Me.cod4 = New System.Windows.Forms.Label()
        Me.cod3 = New System.Windows.Forms.Label()
        Me.Link8 = New System.Windows.Forms.LinkLabel()
        Me.precio8 = New System.Windows.Forms.Label()
        Me.producto8 = New System.Windows.Forms.Label()
        Me.Link7 = New System.Windows.Forms.LinkLabel()
        Me.precio7 = New System.Windows.Forms.Label()
        Me.producto7 = New System.Windows.Forms.Label()
        Me.Link6 = New System.Windows.Forms.LinkLabel()
        Me.precio6 = New System.Windows.Forms.Label()
        Me.producto6 = New System.Windows.Forms.Label()
        Me.Link5 = New System.Windows.Forms.LinkLabel()
        Me.precio5 = New System.Windows.Forms.Label()
        Me.producto5 = New System.Windows.Forms.Label()
        Me.Link4 = New System.Windows.Forms.LinkLabel()
        Me.precio4 = New System.Windows.Forms.Label()
        Me.producto4 = New System.Windows.Forms.Label()
        Me.Link3 = New System.Windows.Forms.LinkLabel()
        Me.precio3 = New System.Windows.Forms.Label()
        Me.producto3 = New System.Windows.Forms.Label()
        Me.Link2 = New System.Windows.Forms.LinkLabel()
        Me.precio2 = New System.Windows.Forms.Label()
        Me.producto2 = New System.Windows.Forms.Label()
        Me.pct8 = New System.Windows.Forms.PictureBox()
        Me.pct7 = New System.Windows.Forms.PictureBox()
        Me.pct5 = New System.Windows.Forms.PictureBox()
        Me.pct6 = New System.Windows.Forms.PictureBox()
        Me.pct4 = New System.Windows.Forms.PictureBox()
        Me.pct2 = New System.Windows.Forms.PictureBox()
        Me.pct3 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbCategoria = New System.Windows.Forms.ComboBox()
        Me.txtBuscador = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnPerfil = New System.Windows.Forms.Button()
        Me.btnAdmin = New System.Windows.Forms.Button()
        Me.btnRegistro = New System.Windows.Forms.Button()
        Me.btnIngresar = New System.Windows.Forms.Button()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.btnAtras = New System.Windows.Forms.Button()
        Me.btnSiguiente = New System.Windows.Forms.Button()
        Me.cod2 = New System.Windows.Forms.Label()
        Me.txtNumSum = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.pct1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pct8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pct7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pct5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pct6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pct4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pct2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pct3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cod1)
        Me.GroupBox1.Controls.Add(Me.Link1)
        Me.GroupBox1.Controls.Add(Me.precio1)
        Me.GroupBox1.Controls.Add(Me.producto1)
        Me.GroupBox1.Controls.Add(Me.pct1)
        Me.GroupBox1.Location = New System.Drawing.Point(41, 250)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(171, 172)
        Me.GroupBox1.TabIndex = 29
        Me.GroupBox1.TabStop = False
        '
        'cod1
        '
        Me.cod1.AutoSize = True
        Me.cod1.Location = New System.Drawing.Point(27, 11)
        Me.cod1.Name = "cod1"
        Me.cod1.Size = New System.Drawing.Size(39, 13)
        Me.cod1.TabIndex = 35
        Me.cod1.Text = "Label3"
        '
        'Link1
        '
        Me.Link1.AutoSize = True
        Me.Link1.Location = New System.Drawing.Point(27, 154)
        Me.Link1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Link1.Name = "Link1"
        Me.Link1.Size = New System.Drawing.Size(54, 13)
        Me.Link1.TabIndex = 10
        Me.Link1.TabStop = True
        Me.Link1.Text = "Ver más..."
        '
        'precio1
        '
        Me.precio1.AutoSize = True
        Me.precio1.Location = New System.Drawing.Point(27, 141)
        Me.precio1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.precio1.Name = "precio1"
        Me.precio1.Size = New System.Drawing.Size(21, 13)
        Me.precio1.TabIndex = 9
        Me.precio1.Text = "U$"
        '
        'producto1
        '
        Me.producto1.AutoSize = True
        Me.producto1.Location = New System.Drawing.Point(27, 128)
        Me.producto1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.producto1.Name = "producto1"
        Me.producto1.Size = New System.Drawing.Size(50, 13)
        Me.producto1.TabIndex = 8
        Me.producto1.Text = "Producto"
        '
        'pct1
        '
        Me.pct1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pct1.Location = New System.Drawing.Point(30, 26)
        Me.pct1.Margin = New System.Windows.Forms.Padding(2)
        Me.pct1.Name = "pct1"
        Me.pct1.Size = New System.Drawing.Size(119, 100)
        Me.pct1.TabIndex = 0
        Me.pct1.TabStop = False
        '
        'cod8
        '
        Me.cod8.AutoSize = True
        Me.cod8.Location = New System.Drawing.Point(27, 13)
        Me.cod8.Name = "cod8"
        Me.cod8.Size = New System.Drawing.Size(39, 13)
        Me.cod8.TabIndex = 41
        Me.cod8.Text = "Label3"
        '
        'cod7
        '
        Me.cod7.AutoSize = True
        Me.cod7.Location = New System.Drawing.Point(22, 13)
        Me.cod7.Name = "cod7"
        Me.cod7.Size = New System.Drawing.Size(39, 13)
        Me.cod7.TabIndex = 40
        Me.cod7.Text = "Label3"
        '
        'cod6
        '
        Me.cod6.AutoSize = True
        Me.cod6.Location = New System.Drawing.Point(20, 12)
        Me.cod6.Name = "cod6"
        Me.cod6.Size = New System.Drawing.Size(39, 13)
        Me.cod6.TabIndex = 39
        Me.cod6.Text = "Label3"
        '
        'cod5
        '
        Me.cod5.AutoSize = True
        Me.cod5.Location = New System.Drawing.Point(27, 12)
        Me.cod5.Name = "cod5"
        Me.cod5.Size = New System.Drawing.Size(39, 13)
        Me.cod5.TabIndex = 38
        Me.cod5.Text = "Label3"
        '
        'cod4
        '
        Me.cod4.AutoSize = True
        Me.cod4.Location = New System.Drawing.Point(27, 11)
        Me.cod4.Name = "cod4"
        Me.cod4.Size = New System.Drawing.Size(39, 13)
        Me.cod4.TabIndex = 37
        Me.cod4.Text = "Label3"
        '
        'cod3
        '
        Me.cod3.AutoSize = True
        Me.cod3.Location = New System.Drawing.Point(22, 11)
        Me.cod3.Name = "cod3"
        Me.cod3.Size = New System.Drawing.Size(39, 13)
        Me.cod3.TabIndex = 36
        Me.cod3.Text = "Label3"
        '
        'Link8
        '
        Me.Link8.AutoSize = True
        Me.Link8.Location = New System.Drawing.Point(31, 157)
        Me.Link8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Link8.Name = "Link8"
        Me.Link8.Size = New System.Drawing.Size(54, 13)
        Me.Link8.TabIndex = 34
        Me.Link8.TabStop = True
        Me.Link8.Text = "Ver más..."
        '
        'precio8
        '
        Me.precio8.AutoSize = True
        Me.precio8.Location = New System.Drawing.Point(31, 142)
        Me.precio8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.precio8.Name = "precio8"
        Me.precio8.Size = New System.Drawing.Size(21, 13)
        Me.precio8.TabIndex = 33
        Me.precio8.Text = "U$"
        '
        'producto8
        '
        Me.producto8.AutoSize = True
        Me.producto8.Location = New System.Drawing.Point(31, 130)
        Me.producto8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.producto8.Name = "producto8"
        Me.producto8.Size = New System.Drawing.Size(50, 13)
        Me.producto8.TabIndex = 32
        Me.producto8.Text = "Producto"
        '
        'Link7
        '
        Me.Link7.AutoSize = True
        Me.Link7.Location = New System.Drawing.Point(24, 157)
        Me.Link7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Link7.Name = "Link7"
        Me.Link7.Size = New System.Drawing.Size(54, 13)
        Me.Link7.TabIndex = 31
        Me.Link7.TabStop = True
        Me.Link7.Text = "Ver más..."
        '
        'precio7
        '
        Me.precio7.AutoSize = True
        Me.precio7.Location = New System.Drawing.Point(24, 143)
        Me.precio7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.precio7.Name = "precio7"
        Me.precio7.Size = New System.Drawing.Size(21, 13)
        Me.precio7.TabIndex = 30
        Me.precio7.Text = "U$"
        '
        'producto7
        '
        Me.producto7.AutoSize = True
        Me.producto7.Location = New System.Drawing.Point(24, 130)
        Me.producto7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.producto7.Name = "producto7"
        Me.producto7.Size = New System.Drawing.Size(50, 13)
        Me.producto7.TabIndex = 29
        Me.producto7.Text = "Producto"
        '
        'Link6
        '
        Me.Link6.AutoSize = True
        Me.Link6.Location = New System.Drawing.Point(18, 156)
        Me.Link6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Link6.Name = "Link6"
        Me.Link6.Size = New System.Drawing.Size(54, 13)
        Me.Link6.TabIndex = 28
        Me.Link6.TabStop = True
        Me.Link6.Text = "Ver más..."
        '
        'precio6
        '
        Me.precio6.AutoSize = True
        Me.precio6.Location = New System.Drawing.Point(18, 141)
        Me.precio6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.precio6.Name = "precio6"
        Me.precio6.Size = New System.Drawing.Size(21, 13)
        Me.precio6.TabIndex = 27
        Me.precio6.Text = "U$"
        '
        'producto6
        '
        Me.producto6.AutoSize = True
        Me.producto6.Location = New System.Drawing.Point(18, 130)
        Me.producto6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.producto6.Name = "producto6"
        Me.producto6.Size = New System.Drawing.Size(50, 13)
        Me.producto6.TabIndex = 26
        Me.producto6.Text = "Producto"
        '
        'Link5
        '
        Me.Link5.AutoSize = True
        Me.Link5.Location = New System.Drawing.Point(27, 156)
        Me.Link5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Link5.Name = "Link5"
        Me.Link5.Size = New System.Drawing.Size(54, 13)
        Me.Link5.TabIndex = 25
        Me.Link5.TabStop = True
        Me.Link5.Text = "Ver más..."
        '
        'precio5
        '
        Me.precio5.AutoSize = True
        Me.precio5.Location = New System.Drawing.Point(27, 142)
        Me.precio5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.precio5.Name = "precio5"
        Me.precio5.Size = New System.Drawing.Size(21, 13)
        Me.precio5.TabIndex = 24
        Me.precio5.Text = "U$"
        '
        'producto5
        '
        Me.producto5.AutoSize = True
        Me.producto5.Location = New System.Drawing.Point(27, 129)
        Me.producto5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.producto5.Name = "producto5"
        Me.producto5.Size = New System.Drawing.Size(50, 13)
        Me.producto5.TabIndex = 23
        Me.producto5.Text = "Producto"
        '
        'Link4
        '
        Me.Link4.AutoSize = True
        Me.Link4.Location = New System.Drawing.Point(27, 154)
        Me.Link4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Link4.Name = "Link4"
        Me.Link4.Size = New System.Drawing.Size(54, 13)
        Me.Link4.TabIndex = 19
        Me.Link4.TabStop = True
        Me.Link4.Text = "Ver más..."
        '
        'precio4
        '
        Me.precio4.AutoSize = True
        Me.precio4.Location = New System.Drawing.Point(27, 140)
        Me.precio4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.precio4.Name = "precio4"
        Me.precio4.Size = New System.Drawing.Size(21, 13)
        Me.precio4.TabIndex = 18
        Me.precio4.Text = "U$"
        '
        'producto4
        '
        Me.producto4.AutoSize = True
        Me.producto4.Location = New System.Drawing.Point(27, 126)
        Me.producto4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.producto4.Name = "producto4"
        Me.producto4.Size = New System.Drawing.Size(50, 13)
        Me.producto4.TabIndex = 17
        Me.producto4.Text = "Producto"
        '
        'Link3
        '
        Me.Link3.AutoSize = True
        Me.Link3.Location = New System.Drawing.Point(22, 154)
        Me.Link3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Link3.Name = "Link3"
        Me.Link3.Size = New System.Drawing.Size(54, 13)
        Me.Link3.TabIndex = 16
        Me.Link3.TabStop = True
        Me.Link3.Text = "Ver más..."
        '
        'precio3
        '
        Me.precio3.AutoSize = True
        Me.precio3.Location = New System.Drawing.Point(22, 140)
        Me.precio3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.precio3.Name = "precio3"
        Me.precio3.Size = New System.Drawing.Size(21, 13)
        Me.precio3.TabIndex = 15
        Me.precio3.Text = "U$"
        '
        'producto3
        '
        Me.producto3.AutoSize = True
        Me.producto3.Location = New System.Drawing.Point(22, 126)
        Me.producto3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.producto3.Name = "producto3"
        Me.producto3.Size = New System.Drawing.Size(50, 13)
        Me.producto3.TabIndex = 14
        Me.producto3.Text = "Producto"
        '
        'Link2
        '
        Me.Link2.AutoSize = True
        Me.Link2.Location = New System.Drawing.Point(19, 154)
        Me.Link2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Link2.Name = "Link2"
        Me.Link2.Size = New System.Drawing.Size(54, 13)
        Me.Link2.TabIndex = 13
        Me.Link2.TabStop = True
        Me.Link2.Text = "Ver más..."
        '
        'precio2
        '
        Me.precio2.AutoSize = True
        Me.precio2.Location = New System.Drawing.Point(19, 141)
        Me.precio2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.precio2.Name = "precio2"
        Me.precio2.Size = New System.Drawing.Size(21, 13)
        Me.precio2.TabIndex = 12
        Me.precio2.Text = "U$"
        '
        'producto2
        '
        Me.producto2.AutoSize = True
        Me.producto2.Location = New System.Drawing.Point(19, 128)
        Me.producto2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.producto2.Name = "producto2"
        Me.producto2.Size = New System.Drawing.Size(50, 13)
        Me.producto2.TabIndex = 11
        Me.producto2.Text = "Producto"
        '
        'pct8
        '
        Me.pct8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pct8.Location = New System.Drawing.Point(30, 28)
        Me.pct8.Margin = New System.Windows.Forms.Padding(2)
        Me.pct8.Name = "pct8"
        Me.pct8.Size = New System.Drawing.Size(119, 100)
        Me.pct8.TabIndex = 7
        Me.pct8.TabStop = False
        '
        'pct7
        '
        Me.pct7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pct7.Location = New System.Drawing.Point(25, 28)
        Me.pct7.Margin = New System.Windows.Forms.Padding(2)
        Me.pct7.Name = "pct7"
        Me.pct7.Size = New System.Drawing.Size(119, 100)
        Me.pct7.TabIndex = 6
        Me.pct7.TabStop = False
        '
        'pct5
        '
        Me.pct5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pct5.Location = New System.Drawing.Point(30, 27)
        Me.pct5.Margin = New System.Windows.Forms.Padding(2)
        Me.pct5.Name = "pct5"
        Me.pct5.Size = New System.Drawing.Size(119, 100)
        Me.pct5.TabIndex = 5
        Me.pct5.TabStop = False
        '
        'pct6
        '
        Me.pct6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pct6.Location = New System.Drawing.Point(21, 27)
        Me.pct6.Margin = New System.Windows.Forms.Padding(2)
        Me.pct6.Name = "pct6"
        Me.pct6.Size = New System.Drawing.Size(119, 100)
        Me.pct6.TabIndex = 4
        Me.pct6.TabStop = False
        '
        'pct4
        '
        Me.pct4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pct4.Location = New System.Drawing.Point(30, 26)
        Me.pct4.Margin = New System.Windows.Forms.Padding(2)
        Me.pct4.Name = "pct4"
        Me.pct4.Size = New System.Drawing.Size(119, 100)
        Me.pct4.TabIndex = 3
        Me.pct4.TabStop = False
        '
        'pct2
        '
        Me.pct2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pct2.Location = New System.Drawing.Point(22, 26)
        Me.pct2.Margin = New System.Windows.Forms.Padding(2)
        Me.pct2.Name = "pct2"
        Me.pct2.Size = New System.Drawing.Size(119, 100)
        Me.pct2.TabIndex = 2
        Me.pct2.TabStop = False
        '
        'pct3
        '
        Me.pct3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pct3.Location = New System.Drawing.Point(25, 26)
        Me.pct3.Margin = New System.Windows.Forms.Padding(2)
        Me.pct3.Name = "pct3"
        Me.pct3.Size = New System.Drawing.Size(119, 100)
        Me.pct3.TabIndex = 1
        Me.pct3.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(296, 135)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(187, 13)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "¡Mercado global con una visión única!"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Impact", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(315, 105)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(151, 29)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Mercado Líder"
        '
        'cmbCategoria
        '
        Me.cmbCategoria.FormattingEnabled = True
        Me.cmbCategoria.Location = New System.Drawing.Point(155, 36)
        Me.cmbCategoria.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbCategoria.Name = "cmbCategoria"
        Me.cmbCategoria.Size = New System.Drawing.Size(92, 21)
        Me.cmbCategoria.TabIndex = 22
        Me.cmbCategoria.Text = "Categoría"
        '
        'txtBuscador
        '
        Me.txtBuscador.Location = New System.Drawing.Point(251, 37)
        Me.txtBuscador.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBuscador.Name = "txtBuscador"
        Me.txtBuscador.Size = New System.Drawing.Size(262, 20)
        Me.txtBuscador.TabIndex = 21
        Me.txtBuscador.Text = "Buscar"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-2, -3)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(817, 249)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 20
        Me.PictureBox1.TabStop = False
        '
        'btnPerfil
        '
        Me.btnPerfil.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPerfil.Location = New System.Drawing.Point(708, 62)
        Me.btnPerfil.Name = "btnPerfil"
        Me.btnPerfil.Size = New System.Drawing.Size(91, 23)
        Me.btnPerfil.TabIndex = 90
        Me.btnPerfil.Text = "Mi Perfil"
        Me.btnPerfil.UseVisualStyleBackColor = True
        Me.btnPerfil.Visible = False
        '
        'btnAdmin
        '
        Me.btnAdmin.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdmin.Location = New System.Drawing.Point(177, 10)
        Me.btnAdmin.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAdmin.Name = "btnAdmin"
        Me.btnAdmin.Size = New System.Drawing.Size(70, 22)
        Me.btnAdmin.TabIndex = 89
        Me.btnAdmin.Text = "Admin"
        Me.btnAdmin.UseVisualStyleBackColor = True
        Me.btnAdmin.Visible = False
        '
        'btnRegistro
        '
        Me.btnRegistro.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRegistro.Location = New System.Drawing.Point(612, 62)
        Me.btnRegistro.Margin = New System.Windows.Forms.Padding(2)
        Me.btnRegistro.Name = "btnRegistro"
        Me.btnRegistro.Size = New System.Drawing.Size(91, 23)
        Me.btnRegistro.TabIndex = 88
        Me.btnRegistro.Text = "Registrarse"
        Me.btnRegistro.UseVisualStyleBackColor = True
        '
        'btnIngresar
        '
        Me.btnIngresar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnIngresar.Location = New System.Drawing.Point(517, 62)
        Me.btnIngresar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnIngresar.Name = "btnIngresar"
        Me.btnIngresar.Size = New System.Drawing.Size(91, 23)
        Me.btnIngresar.TabIndex = 87
        Me.btnIngresar.Text = "Ingresar"
        Me.btnIngresar.UseVisualStyleBackColor = True
        '
        'btnBuscar
        '
        Me.btnBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBuscar.Location = New System.Drawing.Point(517, 36)
        Me.btnBuscar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(91, 22)
        Me.btnBuscar.TabIndex = 86
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.UseVisualStyleBackColor = True
        '
        'btnAtras
        '
        Me.btnAtras.Location = New System.Drawing.Point(297, 601)
        Me.btnAtras.Name = "btnAtras"
        Me.btnAtras.Size = New System.Drawing.Size(84, 23)
        Me.btnAtras.TabIndex = 91
        Me.btnAtras.Text = "Atrás"
        Me.btnAtras.UseVisualStyleBackColor = True
        '
        'btnSiguiente
        '
        Me.btnSiguiente.Location = New System.Drawing.Point(387, 601)
        Me.btnSiguiente.Name = "btnSiguiente"
        Me.btnSiguiente.Size = New System.Drawing.Size(84, 23)
        Me.btnSiguiente.TabIndex = 92
        Me.btnSiguiente.Text = "Siguiente"
        Me.btnSiguiente.UseVisualStyleBackColor = True
        '
        'cod2
        '
        Me.cod2.AutoSize = True
        Me.cod2.Location = New System.Drawing.Point(21, 11)
        Me.cod2.Name = "cod2"
        Me.cod2.Size = New System.Drawing.Size(39, 13)
        Me.cod2.TabIndex = 36
        Me.cod2.Text = "Label3"
        '
        'txtNumSum
        '
        Me.txtNumSum.Location = New System.Drawing.Point(562, 604)
        Me.txtNumSum.Name = "txtNumSum"
        Me.txtNumSum.Size = New System.Drawing.Size(100, 20)
        Me.txtNumSum.TabIndex = 93
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.cod6)
        Me.GroupBox2.Controls.Add(Me.pct6)
        Me.GroupBox2.Controls.Add(Me.producto6)
        Me.GroupBox2.Controls.Add(Me.precio6)
        Me.GroupBox2.Controls.Add(Me.Link6)
        Me.GroupBox2.Location = New System.Drawing.Point(218, 421)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(163, 177)
        Me.GroupBox2.TabIndex = 95
        Me.GroupBox2.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cod4)
        Me.GroupBox3.Controls.Add(Me.pct4)
        Me.GroupBox3.Controls.Add(Me.producto4)
        Me.GroupBox3.Controls.Add(Me.precio4)
        Me.GroupBox3.Controls.Add(Me.Link4)
        Me.GroupBox3.Location = New System.Drawing.Point(572, 250)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(176, 172)
        Me.GroupBox3.TabIndex = 96
        Me.GroupBox3.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.cod8)
        Me.GroupBox4.Controls.Add(Me.pct8)
        Me.GroupBox4.Controls.Add(Me.producto8)
        Me.GroupBox4.Controls.Add(Me.Link8)
        Me.GroupBox4.Controls.Add(Me.precio8)
        Me.GroupBox4.Location = New System.Drawing.Point(572, 421)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(176, 177)
        Me.GroupBox4.TabIndex = 96
        Me.GroupBox4.TabStop = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.cod7)
        Me.GroupBox5.Controls.Add(Me.pct7)
        Me.GroupBox5.Controls.Add(Me.producto7)
        Me.GroupBox5.Controls.Add(Me.precio7)
        Me.GroupBox5.Controls.Add(Me.Link7)
        Me.GroupBox5.Location = New System.Drawing.Point(387, 420)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(179, 178)
        Me.GroupBox5.TabIndex = 96
        Me.GroupBox5.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.cod3)
        Me.GroupBox6.Controls.Add(Me.Link3)
        Me.GroupBox6.Controls.Add(Me.precio3)
        Me.GroupBox6.Controls.Add(Me.producto3)
        Me.GroupBox6.Controls.Add(Me.pct3)
        Me.GroupBox6.Location = New System.Drawing.Point(387, 250)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(179, 172)
        Me.GroupBox6.TabIndex = 96
        Me.GroupBox6.TabStop = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.pct5)
        Me.GroupBox7.Controls.Add(Me.producto5)
        Me.GroupBox7.Controls.Add(Me.precio5)
        Me.GroupBox7.Controls.Add(Me.Link5)
        Me.GroupBox7.Controls.Add(Me.cod5)
        Me.GroupBox7.Location = New System.Drawing.Point(41, 421)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(171, 177)
        Me.GroupBox7.TabIndex = 96
        Me.GroupBox7.TabStop = False
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.cod2)
        Me.GroupBox8.Controls.Add(Me.Link2)
        Me.GroupBox8.Controls.Add(Me.precio2)
        Me.GroupBox8.Controls.Add(Me.producto2)
        Me.GroupBox8.Controls.Add(Me.pct2)
        Me.GroupBox8.Location = New System.Drawing.Point(217, 250)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(164, 172)
        Me.GroupBox8.TabIndex = 96
        Me.GroupBox8.TabStop = False
        '
        'frmBuscador
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(807, 637)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtNumSum)
        Me.Controls.Add(Me.btnSiguiente)
        Me.Controls.Add(Me.btnAtras)
        Me.Controls.Add(Me.btnPerfil)
        Me.Controls.Add(Me.btnAdmin)
        Me.Controls.Add(Me.btnRegistro)
        Me.Controls.Add(Me.btnIngresar)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbCategoria)
        Me.Controls.Add(Me.txtBuscador)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox3)
        Me.Name = "frmBuscador"
        Me.Text = "buscador"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.pct1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pct8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pct7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pct5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pct6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pct4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pct2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pct3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Link8 As LinkLabel
    Friend WithEvents precio8 As Label
    Friend WithEvents producto8 As Label
    Friend WithEvents Link7 As LinkLabel
    Friend WithEvents precio7 As Label
    Friend WithEvents producto7 As Label
    Friend WithEvents Link6 As LinkLabel
    Friend WithEvents precio6 As Label
    Friend WithEvents producto6 As Label
    Friend WithEvents Link5 As LinkLabel
    Friend WithEvents precio5 As Label
    Friend WithEvents producto5 As Label
    Friend WithEvents Link4 As LinkLabel
    Friend WithEvents precio4 As Label
    Friend WithEvents producto4 As Label
    Friend WithEvents Link3 As LinkLabel
    Friend WithEvents precio3 As Label
    Friend WithEvents producto3 As Label
    Friend WithEvents Link2 As LinkLabel
    Friend WithEvents precio2 As Label
    Friend WithEvents producto2 As Label
    Friend WithEvents Link1 As LinkLabel
    Friend WithEvents precio1 As Label
    Friend WithEvents producto1 As Label
    Friend WithEvents pct8 As PictureBox
    Friend WithEvents pct7 As PictureBox
    Friend WithEvents pct5 As PictureBox
    Friend WithEvents pct6 As PictureBox
    Friend WithEvents pct4 As PictureBox
    Friend WithEvents pct2 As PictureBox
    Friend WithEvents pct3 As PictureBox
    Friend WithEvents pct1 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents cmbCategoria As ComboBox
    Friend WithEvents txtBuscador As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnPerfil As Button
    Friend WithEvents btnAdmin As Button
    Friend WithEvents btnRegistro As Button
    Friend WithEvents btnIngresar As Button
    Friend WithEvents btnBuscar As Button
    Friend WithEvents btnAtras As Button
    Friend WithEvents btnSiguiente As Button
    Friend WithEvents cod1 As Label
    Friend WithEvents cod4 As Label
    Friend WithEvents cod3 As Label
    Friend WithEvents cod2 As Label
    Friend WithEvents cod8 As Label
    Friend WithEvents cod7 As Label
    Friend WithEvents cod6 As Label
    Friend WithEvents cod5 As Label
    Friend WithEvents txtNumSum As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents GroupBox8 As GroupBox
End Class
