﻿Public Class frmVentasVendedor
    Dim Base As New conexionBD
    Dim sql As String
    Private Sub frmVentasVendedor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        sql = "SELECT * FROM items"
        Base.CargarTabla(grdVentas, sql)
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        frmAdministrador.Show()
        Me.Close()
    End Sub

End Class