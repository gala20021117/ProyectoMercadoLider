﻿Imports MySql.Data.MySqlClient
Module conexionCombo
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user555; Pwd=140403,Softec;"
End Module
