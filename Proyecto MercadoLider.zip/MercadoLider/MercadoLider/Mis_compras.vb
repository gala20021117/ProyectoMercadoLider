﻿Public Class frmMisCompras

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        frmPerfil.Show()
        Me.Close()
    End Sub

    Private Sub frmMisCompras_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Base As New conexionBD
        Dim sql As String

        sql = "SELECT * FROM items"
        Base.CargarTabla(grdCompras, sql)
    End Sub

End Class