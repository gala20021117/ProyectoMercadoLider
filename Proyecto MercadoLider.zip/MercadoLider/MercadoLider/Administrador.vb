﻿Public Class frmAdministrador
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        frmMenu.Show()
        Me.Close()
    End Sub

    Private Sub btnAdminProd_Click(sender As Object, e As EventArgs) Handles btnAdminProd.Click
        frmAdminProductos.Show()
    End Sub

    Private Sub btnAdminUsuarios_Click(sender As Object, e As EventArgs) Handles btnAdminUsuarios.Click
        frmAdminUsuarios.Show()
    End Sub

    Private Sub btnComprasCliente_Click(sender As Object, e As EventArgs) Handles btnComprasCliente.Click
        frmComprasCliente.Show()
    End Sub

    Private Sub btnVentasVendedor_Click(sender As Object, e As EventArgs) Handles btnVentasVendedor.Click
        frmVentasVendedor.Show()
    End Sub

    Private Sub frmAdministrador_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class