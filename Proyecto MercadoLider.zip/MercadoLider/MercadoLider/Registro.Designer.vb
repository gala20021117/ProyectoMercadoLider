﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRegistro
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRegistro))
        Me.btnRegistrarse = New System.Windows.Forms.Button()
        Me.btnCancelar = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtCont2 = New System.Windows.Forms.TextBox()
        Me.txtApellido = New System.Windows.Forms.TextBox()
        Me.txtNombre = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtCI = New System.Windows.Forms.TextBox()
        Me.txtTelefono = New System.Windows.Forms.TextBox()
        Me.txtDep = New System.Windows.Forms.TextBox()
        Me.txtCiudad = New System.Windows.Forms.TextBox()
        Me.txtDomicilio = New System.Windows.Forms.TextBox()
        Me.txtCasa = New System.Windows.Forms.TextBox()
        Me.txtCont = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpElegir = New System.Windows.Forms.GroupBox()
        Me.btnVendedor = New System.Windows.Forms.RadioButton()
        Me.btnComprador = New System.Windows.Forms.RadioButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnError = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.grpElegir.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnError, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnRegistrarse
        '
        Me.btnRegistrarse.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnRegistrarse.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRegistrarse.Location = New System.Drawing.Point(129, 413)
        Me.btnRegistrarse.Margin = New System.Windows.Forms.Padding(2)
        Me.btnRegistrarse.Name = "btnRegistrarse"
        Me.btnRegistrarse.Size = New System.Drawing.Size(84, 28)
        Me.btnRegistrarse.TabIndex = 70
        Me.btnRegistrarse.Text = "Regisrarse"
        Me.btnRegistrarse.UseVisualStyleBackColor = False
        '
        'btnCancelar
        '
        Me.btnCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelar.Location = New System.Drawing.Point(217, 413)
        Me.btnCancelar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(81, 28)
        Me.btnCancelar.TabIndex = 75
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.White
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(125, 42)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(178, 20)
        Me.Label13.TabIndex = 54
        Me.Label13.Text = "Registro de Usuarios"
        '
        'txtCont2
        '
        Me.txtCont2.Location = New System.Drawing.Point(129, 340)
        Me.txtCont2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCont2.MaxLength = 20
        Me.txtCont2.Name = "txtCont2"
        Me.txtCont2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtCont2.Size = New System.Drawing.Size(169, 20)
        Me.txtCont2.TabIndex = 55
        '
        'txtApellido
        '
        Me.txtApellido.Location = New System.Drawing.Point(129, 102)
        Me.txtApellido.Margin = New System.Windows.Forms.Padding(2)
        Me.txtApellido.MaxLength = 20
        Me.txtApellido.Name = "txtApellido"
        Me.txtApellido.Size = New System.Drawing.Size(169, 20)
        Me.txtApellido.TabIndex = 5
        '
        'txtNombre
        '
        Me.txtNombre.Location = New System.Drawing.Point(129, 78)
        Me.txtNombre.Margin = New System.Windows.Forms.Padding(2)
        Me.txtNombre.MaxLength = 20
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(169, 20)
        Me.txtNombre.TabIndex = 0
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(129, 126)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEmail.MaxLength = 30
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(169, 20)
        Me.txtEmail.TabIndex = 15
        '
        'txtCI
        '
        Me.txtCI.Location = New System.Drawing.Point(129, 152)
        Me.txtCI.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCI.MaxLength = 10
        Me.txtCI.Name = "txtCI"
        Me.txtCI.Size = New System.Drawing.Size(169, 20)
        Me.txtCI.TabIndex = 20
        '
        'txtTelefono
        '
        Me.txtTelefono.Location = New System.Drawing.Point(129, 178)
        Me.txtTelefono.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTelefono.MaxLength = 10
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.Size = New System.Drawing.Size(169, 20)
        Me.txtTelefono.TabIndex = 25
        '
        'txtDep
        '
        Me.txtDep.Location = New System.Drawing.Point(129, 204)
        Me.txtDep.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDep.MaxLength = 15
        Me.txtDep.Name = "txtDep"
        Me.txtDep.Size = New System.Drawing.Size(169, 20)
        Me.txtDep.TabIndex = 30
        '
        'txtCiudad
        '
        Me.txtCiudad.Location = New System.Drawing.Point(129, 229)
        Me.txtCiudad.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCiudad.MaxLength = 30
        Me.txtCiudad.Name = "txtCiudad"
        Me.txtCiudad.Size = New System.Drawing.Size(169, 20)
        Me.txtCiudad.TabIndex = 35
        '
        'txtDomicilio
        '
        Me.txtDomicilio.Location = New System.Drawing.Point(129, 257)
        Me.txtDomicilio.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDomicilio.MaxLength = 20
        Me.txtDomicilio.Name = "txtDomicilio"
        Me.txtDomicilio.Size = New System.Drawing.Size(169, 20)
        Me.txtDomicilio.TabIndex = 40
        '
        'txtCasa
        '
        Me.txtCasa.Location = New System.Drawing.Point(129, 284)
        Me.txtCasa.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCasa.Name = "txtCasa"
        Me.txtCasa.Size = New System.Drawing.Size(169, 20)
        Me.txtCasa.TabIndex = 45
        '
        'txtCont
        '
        Me.txtCont.Location = New System.Drawing.Point(129, 312)
        Me.txtCont.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCont.MaxLength = 20
        Me.txtCont.Name = "txtCont"
        Me.txtCont.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtCont.Size = New System.Drawing.Size(169, 20)
        Me.txtCont.TabIndex = 50
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(65, 378)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(58, 13)
        Me.Label12.TabIndex = 42
        Me.Label12.Text = "Quiere ser:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(24, 340)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(100, 13)
        Me.Label11.TabIndex = 41
        Me.Label11.Text = "Repetir contraseña:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(60, 315)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(64, 13)
        Me.Label10.TabIndex = 40
        Me.Label10.Text = "Contraseña:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(73, 257)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 13)
        Me.Label9.TabIndex = 39
        Me.Label9.Text = "Domicilio:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(57, 284)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 13)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "N° casa, apt:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(77, 229)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(43, 13)
        Me.Label7.TabIndex = 37
        Me.Label7.Text = "Ciudad:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(43, 204)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 13)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "Departamento:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(71, 178)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Teléfono:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(57, 152)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Documento:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(81, 126)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "E-mail:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(77, 101)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Apellido:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(77, 78)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Nombre:"
        '
        'grpElegir
        '
        Me.grpElegir.BackColor = System.Drawing.Color.White
        Me.grpElegir.Controls.Add(Me.btnVendedor)
        Me.grpElegir.Controls.Add(Me.btnComprador)
        Me.grpElegir.Location = New System.Drawing.Point(129, 364)
        Me.grpElegir.Margin = New System.Windows.Forms.Padding(2)
        Me.grpElegir.Name = "grpElegir"
        Me.grpElegir.Padding = New System.Windows.Forms.Padding(2)
        Me.grpElegir.Size = New System.Drawing.Size(169, 45)
        Me.grpElegir.TabIndex = 55
        Me.grpElegir.TabStop = False
        '
        'btnVendedor
        '
        Me.btnVendedor.AutoSize = True
        Me.btnVendedor.Location = New System.Drawing.Point(84, 17)
        Me.btnVendedor.Margin = New System.Windows.Forms.Padding(2)
        Me.btnVendedor.Name = "btnVendedor"
        Me.btnVendedor.Size = New System.Drawing.Size(71, 17)
        Me.btnVendedor.TabIndex = 65
        Me.btnVendedor.TabStop = True
        Me.btnVendedor.Text = "Vendedor"
        Me.btnVendedor.UseVisualStyleBackColor = True
        '
        'btnComprador
        '
        Me.btnComprador.AutoSize = True
        Me.btnComprador.Location = New System.Drawing.Point(4, 16)
        Me.btnComprador.Margin = New System.Windows.Forms.Padding(2)
        Me.btnComprador.Name = "btnComprador"
        Me.btnComprador.Size = New System.Drawing.Size(76, 17)
        Me.btnComprador.TabIndex = 60
        Me.btnComprador.TabStop = True
        Me.btnComprador.Text = "Comprador"
        Me.btnComprador.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-1, -23)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(439, 568)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 56
        Me.PictureBox1.TabStop = False
        '
        'btnError
        '
        Me.btnError.ContainerControl = Me
        '
        'frmRegistro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(435, 540)
        Me.Controls.Add(Me.btnRegistrarse)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.txtCont2)
        Me.Controls.Add(Me.txtApellido)
        Me.Controls.Add(Me.txtNombre)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtCI)
        Me.Controls.Add(Me.txtTelefono)
        Me.Controls.Add(Me.txtDep)
        Me.Controls.Add(Me.txtCiudad)
        Me.Controls.Add(Me.txtDomicilio)
        Me.Controls.Add(Me.txtCasa)
        Me.Controls.Add(Me.txtCont)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grpElegir)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmRegistro"
        Me.Text = "Registro"
        Me.grpElegir.ResumeLayout(False)
        Me.grpElegir.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnError, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnRegistrarse As Button
    Friend WithEvents btnCancelar As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents txtCont2 As TextBox
    Friend WithEvents txtApellido As TextBox
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtCI As TextBox
    Friend WithEvents txtTelefono As TextBox
    Friend WithEvents txtDep As TextBox
    Friend WithEvents txtCiudad As TextBox
    Friend WithEvents txtDomicilio As TextBox
    Friend WithEvents txtCasa As TextBox
    Friend WithEvents txtCont As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents grpElegir As GroupBox
    Friend WithEvents btnComprador As RadioButton
    Friend WithEvents btnVendedor As RadioButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnError As ErrorProvider
End Class
