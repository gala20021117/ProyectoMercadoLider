﻿Public Class frmComprasCliente
    Dim Base As New conexionBD
    Dim sql As String
    Private Sub frmComprasCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        sql = "SELECT compras.IdCompra, compras.PrecioTotal, compras.Fecha, compras.IdUsuario, usuarios.nombre FROM compras JOIN usuarios ON compras.IdUsuario=usuarios.IdUsuario"
        Base.CargarTabla(grdCompras, sql)
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        frmAdministrador.Show()
        Me.Close()
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        sql = "SELECT compras.IdCompra , compras.PrecioTotal, compras.Fecha, compras.IdUsuario, usuarios.nombre  FROM compras JOIN usuarios ON compras.IdUsuario=usuarios.Idusuario WHERE usuarios.Nombre LIKE '%" & txtBuscar.Text & "%' "
        Base.CargarTabla(grdCompras, sql)
    End Sub

End Class