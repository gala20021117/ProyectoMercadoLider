﻿Imports MySql.Data.MySqlClient
Public Class conexionBD
    Private conexion As New MySqlConnection
    Private cmd As New MySqlCommand
    Private Adapter As New MySqlDataAdapter

    Public Sub New()
        Try
            conexion.ConnectionString = "server=localhost; database=mercado_lider; Uid=user555; Pwd=140403,Softec;"
            conexion.Open()
            cmd.Connection = conexion

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error")
        End Try

    End Sub

    Public Sub EjecutarSQL(ByVal sentenciaSQL As String)
        cmd.CommandText = sentenciaSQL
        cmd.ExecuteNonQuery()

    End Sub

    Public Sub CargarTabla(ByVal Tabla As DataGridView, ByVal SQL As String)
        Try
            Me.EjecutarSQL(SQL)
            Adapter = New MySqlDataAdapter(Me.cmd)
            Dim DT As New DataTable
            Adapter.Fill(DT)
            Tabla.DataSource = DT

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

End Class
