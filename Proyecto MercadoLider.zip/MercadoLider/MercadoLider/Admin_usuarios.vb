﻿Imports MySql.Data.MySqlClient

Public Class frmAdminUsuarios
    Dim Base As New conexionBD
    Dim sql As String
    Dim conexion As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter
    Dim ds As DataSet = New DataSet

    Private Sub frmAdminUsuarios_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Base As New conexionBD
        Dim sql As String
        sql = "SELECT usuarios.IdUsuario, usuarios.Nombre, usuarios.Apellido, usuarios.Calle, usuarios.NumCasa, usuarios.Ciudad, usuarios.Departamento, usuarios.IdRol, usuarios.Contraseña, contactousuario.Telefono, contactousuario.Email FROM usuarios, contactousuario WHERE usuarios.IdUsuario=contactousuario.IdUsuario"
        Base.CargarTabla(grdUsuarios, sql)
    End Sub
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        frmAdministrador.Show()
        Me.Close()
    End Sub

    Private Sub txtBuscar_Click(sender As Object, e As EventArgs) Handles txtBuscar.Click
        Dim Base As New conexionBD
        Dim sql As String
        sql = "SELECT * FROM `usuarios` WHERE `Nombre` LIKE '%" & txtBuscarUs.Text & "%' "
        Base.CargarTabla(grdUsuarios, sql)
    End Sub

    Sub ActualizarSelect()
        Try
            conexion.Open()
            cmd.Connection = conexion

            cmd.CommandText = "SELECT usuarios.IdUsuario, usuarios.Nombre, usuarios.Apellido, usuarios.Calle, usuarios.NumCasa, usuarios.Ciudad, usuarios.Departamento, usuarios.IdRol, usuarios.Contraseña, contactousuario.Telefono, contactousuario.Email FROM usuarios, contactousuario WHERE usuarios.IdUsuario=contactousuario.IdUsuario"
            adaptador.SelectCommand = cmd
            adaptador.Fill(ds, "Tabla")
            grdUsuarios.DataSource = ds
            grdUsuarios.DataMember = "Tabla"

            conexion.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnEliminarUs_Click(sender As Object, e As EventArgs) Handles btnEliminarUs.Click
        Dim respuesta As Byte

        respuesta = MsgBox("¿Esta seguro que desea eliminar este registro?", vbYesNo, "Eliminar")
        If respuesta = vbYes Then

            Try
                conexion.Open()
                cmd.Connection = conexion
                cmd.CommandText = "DELETE usuarios, contactousuario FROM `usuarios` JOIN `contactousuario` ON `usuarios`.`IdUsuario`=`contactousuario`.`IdUsuario`"
                cmd.Prepare()
                conexion.Close()

                ActualizarSelect()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub
End Class