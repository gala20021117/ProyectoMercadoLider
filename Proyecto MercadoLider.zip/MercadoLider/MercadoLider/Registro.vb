﻿Imports System.ComponentModel
Imports System.Data.OleDb
Imports MySql.Data.MySqlClient

Public Class frmRegistro
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user555; Pwd=140403,Softec;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand

    Dim ver As Boolean = False
    Dim rol As Integer

    Function ExistenciaUsuario(ByVal documento As String) As Boolean
        Dim DataAdapter As MySqlDataAdapter = New MySqlDataAdapter
        Dim oDataSet As New DataSet
        Try
            conexion.Open()
            cmd = conexion.CreateCommand
            cmd.CommandText = "Select IdUsuario FROM usuarios WHERE IdUsuario=@IdUsuario"
            cmd.Prepare()
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@IdUsuario", documento)
            DataAdapter.SelectCommand = cmd

            oDataSet.Reset()
            DataAdapter.Fill(oDataSet, "Tabla")

            If (oDataSet.Tables("Tabla").Rows.Count() = 1) Then
                ver = True
            Else
                ver = False
            End If

            conexion.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Return ver
    End Function

    Private Sub btnRegistrarse_Click(sender As Object, e As EventArgs) Handles btnRegistrarse.Click

        If Me.ValidateChildren And txtNombre.Text <> String.Empty And txtApellido.Text <> String.Empty And txtEmail.Text <> String.Empty And txtCI.Text <> String.Empty And txtTelefono.Text <> String.Empty And txtDep.Text <> String.Empty And txtCiudad.Text <> String.Empty And txtDomicilio.Text <> String.Empty And txtCasa.Text <> String.Empty And txtCont.Text <> String.Empty And txtCont2.Text <> String.Empty Then

            If ExistenciaUsuario(txtCI.Text) = True Then
                MsgBox("Este usuario ya existe", MsgBoxStyle.Critical)

            ElseIf txtCont.Text <> txtCont2.Text Then
                MsgBox("Las contraseñas no coinciden")

            ElseIf txtCont.Text = txtCont2.Text Then

                Try
                    If txtCont.Text = txtCont2.Text Then

                    End If

                    If btnComprador.Checked = True Then
                        rol = 1
                        'Cliente
                    ElseIf btnVendedor.Checked = True Then
                        rol = 2
                        'Vendedor
                    Else
                        MsgBox("Seleccione una opción")
                    End If

                    conexion.Open()
                    cmd = conexion.CreateCommand
                    cmd.CommandText = "INSERT INTO usuarios(IdUsuario, Nombre, Apellido, Calle, NumCasa, Ciudad, Departamento, IdRol, Contraseña) VALUES(@IdUsuario, @Nombre, @Apellido, @Calle, @NumCasa, @Ciudad, @Departamento, @IdRol, @Contraseña); INSERT INTO contactousuario(IdUsuario, Telefono, Email) VALUES(@IdUsuario, @Telefono, @Email);"

                    cmd.Prepare()
                    cmd.Parameters.Clear()
                    cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text)
                    cmd.Parameters.AddWithValue("@Contraseña", txtCont.Text)
                    cmd.Parameters.AddWithValue("@Apellido", txtApellido.Text)
                    cmd.Parameters.AddWithValue("@IdUsuario", txtCI.Text)
                    cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text)
                    cmd.Parameters.AddWithValue("@Calle", txtDomicilio.Text)
                    cmd.Parameters.AddWithValue("@NumCasa", txtCasa.Text)
                    cmd.Parameters.AddWithValue("@Ciudad", txtCiudad.Text)
                    cmd.Parameters.AddWithValue("@Departamento", txtDep.Text)
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text)
                    cmd.Parameters.AddWithValue("@IdRol", rol)
                    cmd.ExecuteNonQuery()
                    'MsgBox("Conexión establecida.")
                    conexion.Close()

                    txtNombre.Clear()
                    txtCont.Clear()
                    txtApellido.Clear()
                    txtCI.Clear()
                    txtTelefono.Clear()
                    txtDomicilio.Clear()
                    txtCasa.Clear()
                    txtCiudad.Clear()
                    txtDep.Clear()
                    txtEmail.Clear()
                    txtCont2.Clear()


                    MessageBox.Show("Datos correctamente registrados", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Me.Hide()
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.Critical, "Error")
                    conexion.Close()
                End Try
            Else
                MessageBox.Show("Ingrese todos los datos", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If

    End Sub

    Private Sub txtNombre_Validating(sender As Object, e As CancelEventArgs) Handles txtNombre.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un nombre")

        End If
    End Sub

    Private Sub txtApellido_Validating(sender As Object, e As CancelEventArgs) Handles txtApellido.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un apellido")

        End If
    End Sub

    Private Sub txtEmail_Validating(sender As Object, e As CancelEventArgs) Handles txtEmail.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un Email")

        End If
    End Sub

    Private Sub txtDep_Validating(sender As Object, e As CancelEventArgs) Handles txtDep.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un departamento")

        End If
    End Sub

    Private Sub txtCiudad_Validating(sender As Object, e As CancelEventArgs) Handles txtCiudad.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese una ciudad")

        End If
    End Sub

    Private Sub txtDomicilio_Validating(sender As Object, e As CancelEventArgs) Handles txtDomicilio.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un domicilio")

        End If
    End Sub


    Private Sub txtCI_Validating(sender As Object, e As CancelEventArgs) Handles txtCI.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su cedula")

        End If
    End Sub

    Private Sub txtTelefono_Validating(sender As Object, e As CancelEventArgs) Handles txtTelefono.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un telefono o celular")

        End If
    End Sub

    Private Sub txtCasa_Validating(sender As Object, e As CancelEventArgs) Handles txtCasa.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un numero de casa o apt")

        End If
    End Sub

    Private Sub txtCont_Validating(sender As Object, e As CancelEventArgs) Handles txtCont.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese una contraseña")

        End If
    End Sub

    Private Sub txtCont2_Validating(sender As Object, e As CancelEventArgs) Handles txtCont2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Repita la contraseña")

        End If
    End Sub


    Private Sub txtCI_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCI.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtTelefono_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTelefono.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCasa_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCasa.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub


    Private Sub txtNombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNombre.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtApellido_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtApellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub


    Private Sub txtDep_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDep.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCiudad_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCiudad.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtUsuario_Validating(sender As Object, e As CancelEventArgs)
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un nombre de usuario. Puede incluir números")

        End If
    End Sub

    Private Sub txtUsuario_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        frmMenu.Show()
        Me.Close()
    End Sub

    Private Sub frmRegistro_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class