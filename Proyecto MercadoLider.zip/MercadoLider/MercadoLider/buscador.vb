﻿Public Class frmBuscador
    Private Sub btnIngresar_Click(sender As Object, e As EventArgs)
        frmIngreso.Show()

    End Sub

    Private Sub btnAdmin_Click(sender As Object, e As EventArgs)
        frmAdministrador.Show()


    End Sub

    Private Sub btnRegistro_Click(sender As Object, e As EventArgs)
        frmRegistro.Show()

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Link1.LinkClicked
        frmProducto.Show()

    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Link2.LinkClicked
        frmProducto.Show()
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Link3.LinkClicked
        frmProducto.Show()
    End Sub

    Private Sub LinkLabel4_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Link4.LinkClicked
        frmProducto.Show()
    End Sub

    Private Sub LinkLabel8_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Link8.LinkClicked
        frmProducto.Show()
    End Sub

    Private Sub LinkLabel7_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Link7.LinkClicked
        frmProducto.Show()
    End Sub

    Private Sub LinkLabel5_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Link6.LinkClicked
        frmProducto.Show()
    End Sub

    Private Sub LinkLabel6_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Link5.LinkClicked
        frmProducto.Show()
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnPerfil_Click(sender As Object, e As EventArgs)
        frmPerfil.Show()
    End Sub

    Private Sub btnBuscar_Click_1(sender As Object, e As EventArgs) Handles btnBuscar.Click
        Dim a As String = ""
        Dim sumresta = 0
        Dim restar As Boolean = False
        Dim b As String = ""
        Dim c As String = ""

        buscador(txtBuscador.Text, a, sumresta, restar, b, c)

    End Sub

    Private Sub frmBuscador_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pct1.SizeMode = PictureBoxSizeMode.Zoom
        pct2.SizeMode = PictureBoxSizeMode.Zoom
        pct3.SizeMode = PictureBoxSizeMode.Zoom
        pct4.SizeMode = PictureBoxSizeMode.Zoom
        pct5.SizeMode = PictureBoxSizeMode.Zoom
        pct6.SizeMode = PictureBoxSizeMode.Zoom
        pct7.SizeMode = PictureBoxSizeMode.Zoom
        pct8.SizeMode = PictureBoxSizeMode.Zoom
    End Sub

    Private Sub btnSiguiente_Click(sender As Object, e As EventArgs) Handles btnSiguiente.Click
        Dim a As String = ""
        Dim sum As Integer = 8
        Dim sum1 As Integer = Val(txtNumSum.Text)
        Dim pasoTT As Integer
        pasoTT = sum1 + sum
        txtNumSum.Text = pasoTT
        Dim restar As Boolean = False
        Dim b As String = ""
        Dim c As String = ""
        buscador(txtBuscador.Text, a, sum, restar, b, c)

    End Sub

    Private Sub btnCerrar_Click(sender As Object, e As EventArgs) 
        frmMenu.Show()
        Me.Close()
    End Sub

    Private Sub btnCerrar_Click_1(sender As Object, e As EventArgs)
        End
    End Sub
End Class