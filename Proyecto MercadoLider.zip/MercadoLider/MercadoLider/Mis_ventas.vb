﻿Public Class frmVentas
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        frmPerfil.Show()
        Me.Close()
    End Sub

    Private Sub frmMisPublicaciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Base As New conexionBD
        Dim sql As String
        sql = "SELECT articulos.Nombre, articulos.Descripcion, articulos.IdCategoria, items.Precio, items.Cantidad, compras.PrecioTotal, compras.Fecha FROM articulos, items, compras WHERE articulos.Codigo=items.IdArticulo AND compras.IdCompra=items.IdCompra"
        Base.CargarTabla(grdVentas, sql)
    End Sub

End Class