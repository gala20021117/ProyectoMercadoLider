﻿Imports MySql.Data.MySqlClient
Public Class frmProducto
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user555; Pwd=140403,Softec;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Dim ds As DataSet = New DataSet
    Dim adaptador As MySqlDataAdapter = New MySqlDataAdapter

    Private Sub btnComprar_Click(sender As Object, e As EventArgs) Handles btnComprar.Click
        frmComprar.Show()

    End Sub

End Class