﻿Imports MySql.Data.MySqlClient
Public Class frmMenu
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user555; Pwd=140403,Softec;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Dim adaptador As MySqlDataAdapter
    Dim tabla As DataTable
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        frmIngreso.Show()

    End Sub

    Private Sub btnRegistro_Click(sender As Object, e As EventArgs) Handles btnRegistro.Click
        frmRegistro.Show()
    End Sub

    Private Sub btnAdmin_Click(sender As Object, e As EventArgs) Handles btnAdmin.Click
        frmAdministrador.Show()

    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        Dim a As String = ""
        Dim sumresta = 0
        Dim restar As Boolean = False
        Dim b As String = ""
        Dim c As String = ""

        buscador(txtBuscador.Text, a, sumresta, restar, b, c)

        frmBuscador.Show()
    End Sub

    Private Sub btnPerfil_Click(sender As Object, e As EventArgs) Handles btnPerfil.Click
        frmPerfil.Show()
    End Sub

    Private Sub frmMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            adaptador = New MySqlDataAdapter("SELECT IdCategoria, Nombre FROM categoria", conexion)
            tabla = New DataTable
            adaptador.Fill(tabla)

            Call LlenarComboBox()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub LlenarComboBox()
        For Each fila As DataRow In tabla.Rows
            cmbCateg.Items.Add(fila("IdCategoria"))
            cmbCateg.Items.Add(fila("Nombre"))
        Next
    End Sub

    Private Sub btnCerrar_Click(sender As Object, e As EventArgs) 
        End

    End Sub
End Class
