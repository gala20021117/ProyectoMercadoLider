﻿Imports System.ComponentModel
Imports MySql.Data.MySqlClient

Public Class frmIngreso
    Dim server As String = "server=localhost; database=mercado_lider; Uid=user555; Pwd=140403,Softec;"
    Dim conexion As New MySqlConnection(server)
    Dim cmd As New MySqlCommand
    Dim DataAdapter As New MySqlDataAdapter
    Dim oDataSet As New DataSet
    Dim Sql, Sql2 As String
    Dim ver As Boolean = False

    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        '1 = Cliente
        '2 = Vendedor
        '3 = Administrador

        If ExistenciaUsuario(txtCI.Text, txtContraseña.Text) = 1 Or ExistenciaUsuario(txtCI.Text, txtContraseña.Text) = 2 Or ExistenciaUsuario(txtCI.Text, txtContraseña.Text) = 3 Then
            frmMenu.Visible = False
            frmMenu.ShowDialog()
            Me.Hide()


        Else
            MsgBox("Datos ingresados incorrectamente", MsgBoxStyle.Critical)

        End If

        txtCI.Text.DefaultIfEmpty
        txtContraseña.Text.DefaultIfEmpty
    End Sub

    Private Sub txtEmail_Validating(sender As Object, e As CancelEventArgs) Handles txtCI.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")

        Else
            Me.btnError.SetError(sender, "Ingrese un Email")

        End If
    End Sub

    Private Sub txtContraseña_Validating(sender As Object, e As CancelEventArgs) Handles txtContraseña.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su contraseña")

        End If
    End Sub
    Private Sub lblContraseña_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblContraseña.LinkClicked
        frmContraseña.Show()


    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        frmMenu.Show()
        Me.Close()
    End Sub

    Private Sub frmIngreso_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


    Function ExistenciaUsuario(ByVal usuario As String, ByVal pass As String) As Integer
        Dim ver As Integer

        Try
            conexion.ConnectionString = "server=localhost; database=mercado_lider;Uid=user333; Pwd=171102,Megals;"
            Sql = "SELECT * FROM usuarios WHERE IdUsuario='" & usuario & "' AND Contraseña='" & pass & "'"

            conexion.Open()
            DataAdapter = New MySqlDataAdapter(Sql, conexion)
            oDataSet.Clear()
            DataAdapter.Fill(oDataSet, "usuarios")


            If (oDataSet.Tables("usuarios").Rows.Count() = 1) Then
                'Si el usuario si existe:
                Dim num As Integer
                'Verificar que rol tiene
                num = oDataSet.Tables("usuarios").Rows(0).Item("IdRol")

                If num = 1 Then
                    ver = 1
                    frmPerfil.btnVender.Visible = False
                    frmPerfil.btnPublicaciones.Visible = False
                    frmPerfil.btnVentas.Visible = False
                    frmPerfil.grpVentas.Visible = False
                    frmMenu.btnAdmin.Visible = False
                    frmMenu.btnPerfil.Visible = True
                    frmMenu.btnIngresar.Visible = False
                    'El usuario es cliente
                ElseIf num = 2 Then
                    ver = 2
                    'El usuario es vendedor
                    frmPerfil.btnCompras.Visible = False
                    frmPerfil.grpCompras.Visible = False
                    frmMenu.btnAdmin.Visible = False
                    frmMenu.btnPerfil.Visible = True
                    frmMenu.btnIngresar.Visible = False
                ElseIf num = 3 Then
                    ver = 3
                    frmMenu.btnAdmin.Visible = True
                    frmMenu.btnPerfil.Visible = True
                    frmMenu.btnIngresar.Visible = False
                    'El usuario es administrador
                End If

            Else
                ver = 4
                'El usuario no existe

            End If
            conexion.Close()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
        Return ver
    End Function


End Class